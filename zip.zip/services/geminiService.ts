
import { GoogleGenAI, Chat } from "@google/genai";
import { GEMINI_SYSTEM_INSTRUCTION } from '../constants';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const initChat = async (): Promise<Chat> => {
  const chat = ai.chats.create({
    model: 'gemini-2.5-flash',
    config: {
      systemInstruction: GEMINI_SYSTEM_INSTRUCTION,
    },
  });
  return chat;
};

export const streamMessage = async (chat: Chat, message: string): Promise<AsyncIterable<string>> => {
  const result = await chat.sendMessageStream({ message });

  const stream = (async function*() {
    for await (const chunk of result) {
      yield chunk.text;
    }
  })();

  return stream;
};
