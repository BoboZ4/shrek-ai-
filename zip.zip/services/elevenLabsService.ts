

// Use environment variable if available, otherwise fallback to the provided key.
const API_KEY = process.env.ELEVENLABS_API_KEY || 'sk_f053f1c6ec9a41ab96d15de5ff0ea59ad592563df4195eff';
const API_URL = 'https://api.elevenlabs.io/v1';

interface ElevenLabsVoice {
  voice_id: string;
  name: string;
}

export const getElevenLabsVoices = async (): Promise<ElevenLabsVoice[]> => {
  if (!API_KEY) {
    // This error is now unlikely to be thrown but kept as a safeguard.
    throw new Error("ELEVENLABS_API_KEY is not set in environment variables or as a fallback.");
  }

  const response = await fetch(`${API_URL}/voices`, {
    headers: {
      'xi-api-key': API_KEY,
    },
  });

  if (!response.ok) {
    console.error("Failed to fetch ElevenLabs voices:", response.status, response.statusText);
    if (response.status === 401) {
      throw new Error("האימות מול ElevenLabs נכשל. מפתח ה-API אינו תקין או שאין לו הרשאות.");
    }
    return [];
  }

  const data = await response.json();
  return data.voices;
};

export const streamElevenLabsAudio = async (text: string, voiceId: string): Promise<Blob | null> => {
  if (!API_KEY) {
    throw new Error("ELEVENLABS_API_KEY is not set in environment variables or as a fallback.");
  }
  
  const response = await fetch(`${API_URL}/text-to-speech/${voiceId}/stream`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'xi-api-key': API_KEY,
    },
    body: JSON.stringify({
      text: text,
      model_id: 'eleven_multilingual_v2',
      voice_settings: {
        stability: 0.5,
        similarity_boost: 0.75,
      },
    }),
  });

  if (!response.ok) {
    console.error('ElevenLabs API error:', response.status, response.statusText);
    return null;
  }

  return response.blob();
};
