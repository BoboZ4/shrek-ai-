import React from 'react';
import { APP_NAME } from '../constants';
import { SoulIcon } from './Icons';

export const Header: React.FC = () => {
  return (
    <header className="text-center py-4 border-b border-gray-700">
      <div className="flex items-center justify-center gap-4">
        <SoulIcon className="w-12 h-12 text-yellow-400" />
        <div>
            <h1 className="text-4xl font-bold tracking-tight text-white">{APP_NAME}</h1>
            <p className="text-sm text-gray-400" style={{ fontFamily: 'Lora, serif' }}>העתיד של שיח לנשמה.</p>
        </div>
      </div>
    </header>
  );
};