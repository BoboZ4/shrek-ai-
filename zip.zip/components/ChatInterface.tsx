import React, { useState, useRef, useEffect, useCallback } from 'react';
import type { ChatMessage } from '../types';
import { Sender } from '../types';
import { MessageBubble } from './MessageBubble';
import { SendIcon, StopIcon, MicrophoneIcon } from './Icons';
import { useSpeechToText } from '../hooks/useSpeechToText';

interface ChatInterfaceProps {
  messages: ChatMessage[];
  onSendMessage: (text: string) => void;
  isLoading: boolean;
  isSpeaking: boolean;
  stopSpeaking: () => void;
  speakingMessageId: string | null;
}

export const ChatInterface: React.FC<ChatInterfaceProps> = ({ 
  messages, onSendMessage, isLoading, isSpeaking, stopSpeaking, speakingMessageId 
}) => {
  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const { isListening, transcript, startListening, stopListening, hasSpeechRecognition } = useSpeechToText();

  useEffect(() => {
    if (transcript) {
      setInput(prev => prev ? `${prev} ${transcript}` : transcript);
    }
  }, [transcript]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);
  
  const handleSend = useCallback(() => {
    if (!input.trim() || isLoading) return;
    onSendMessage(input);
    setInput('');
  }, [input, isLoading, onSendMessage]);

  const handleMicToggle = () => {
    if (isListening) {
      stopListening();
    } else {
      if (isSpeaking) {
        stopSpeaking();
      }
      setInput(''); // Clear input for better voice UX
      startListening();
    }
  };
  
  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    // Maybe show a toast notification here in a future version
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    if (isSpeaking) {
      stopSpeaking();
    }
    setInput(e.target.value);
  }

  const getPlClass = useCallback(() => {
    // Dynamically set padding to prevent buttons from overlapping text.
    // pl-16: Send button only
    // pl-28: Two buttons (e.g., Mic + Send)
    // pl-36: Three buttons (e.g., Stop + Mic + Send)
    if (isSpeaking && hasSpeechRecognition) return 'pl-36';
    if (isSpeaking || hasSpeechRecognition) return 'pl-28';
    return 'pl-16';
  }, [isSpeaking, hasSpeechRecognition]);

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {messages.map((msg) => (
          <MessageBubble 
            key={msg.id} 
            message={msg} 
            isCurrentlySpeaking={speakingMessageId === msg.id}
            onCopy={handleCopy}
            isLoading={isLoading && msg.sender === Sender.AI && msg.text === ''}
          />
        ))}
        <div ref={messagesEndRef} />
      </div>
      <div className="p-4 border-t border-gray-700 bg-gray-800/50">
        <div className="relative">
          <textarea
            value={input}
            onChange={handleInputChange}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            placeholder={isListening ? 'מקשיב...' : 'שתפו מה על ליבכם...'}
            className={`w-full bg-gray-900 border border-gray-600 rounded-lg p-3 ${getPlClass()} text-white placeholder-gray-500 focus:ring-2 focus:ring-yellow-400 focus:outline-none resize-none transition-all`}
            rows={2}
            disabled={isLoading}
          />
          <div className="absolute left-3 top-1/2 -translate-y-1/2 flex items-center gap-2">
            {isSpeaking && (
              <button
                onClick={stopSpeaking}
                className="p-2 rounded-full bg-red-500/80 hover:bg-red-500 text-white transition-colors"
                aria-label="הפסק דיבור"
              >
                <StopIcon className="w-5 h-5" />
              </button>
            )}
             {hasSpeechRecognition && (
                <button
                  onClick={handleMicToggle}
                  disabled={isLoading}
                  className={`p-2 rounded-full transition-colors ${isListening ? 'bg-yellow-400/20 text-yellow-400 animate-pulse' : 'text-gray-400 hover:text-white'}`}
                  aria-label={isListening ? 'הפסק להקשיב' : 'התחל להקשיב'}
                >
                  <MicrophoneIcon className="w-5 h-5" />
                </button>
              )}
            <button
              onClick={handleSend}
              disabled={!input.trim() || isLoading}
              className="p-3 rounded-full bg-yellow-400 hover:bg-yellow-500 disabled:bg-gray-600 disabled:cursor-not-allowed text-gray-900 transition-colors"
              aria-label="שלח הודעה"
            >
              <SendIcon className="w-6 h-6 transform -scale-x-100" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};