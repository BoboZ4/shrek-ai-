import React, { useState } from 'react';
import type { ChatMessage } from '../types';
import { Sender } from '../types';
import { SoulIcon, UserIcon, CopyIcon, CheckIcon } from './Icons';

interface MessageBubbleProps {
  message: ChatMessage;
  isLoading?: boolean;
  isCurrentlySpeaking?: boolean;
  onCopy: (text: string) => void;
}

export const MessageBubble: React.FC<MessageBubbleProps> = ({ message, isLoading = false, isCurrentlySpeaking = false, onCopy }) => {
  const [copied, setCopied] = useState(false);
  const isAI = message.sender === Sender.AI;

  const textWithLineBreaks = message.text.split('\n').map((line, index) => (
    <React.Fragment key={index}>
      {line}
      <br />
    </React.Fragment>
  ));

  const handleCopyClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onCopy(message.text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000); // show confirmation for 2 seconds
  };

  return (
    <div className={`flex items-start gap-4 ${isAI ? '' : 'flex-row-reverse'}`}>
      <div className={`flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center ${isAI ? 'bg-yellow-400/20 text-yellow-400' : 'bg-gray-600'}`}>
        {isAI ? <SoulIcon className="w-6 h-6" /> : <UserIcon className="w-6 h-6" />}
      </div>
      <div className={`relative group max-w-xl p-4 rounded-lg transition-all duration-300 ${
        isAI 
          ? 'bg-gradient-to-br from-gray-700 to-gray-800 text-gray-200 rounded-tr-none' 
          : 'bg-blue-600/80 text-white rounded-tl-none'
      } ${isCurrentlySpeaking ? 'shadow-lg shadow-yellow-400/30 ring-2 ring-yellow-400/50' : ''} ${isLoading ? 'animate-pulse' : ''}`}>
        <div className="prose prose-invert prose-sm text-right" style={{ fontFamily: 'Lora, serif' }}>
          {isLoading ? (
            <div className="h-6 w-24 bg-gray-600 rounded"></div>
          ) : (
            textWithLineBreaks
          )}
        </div>
        {isAI && !isLoading && (
          <button 
            onClick={handleCopyClick}
            className="absolute -top-3 -left-3 p-1.5 bg-gray-600 rounded-full text-gray-300 hover:bg-gray-500 hover:text-white transition-all opacity-0 group-hover:opacity-100 disabled:opacity-50"
            aria-label={copied ? "ההודעה הועתקה" : "העתק הודעה"}
            disabled={copied}
          >
            {copied ? <CheckIcon className="w-5 h-5 text-green-400" /> : <CopyIcon className="w-5 h-5" />}
          </button>
        )}
      </div>
    </div>
  );
};
