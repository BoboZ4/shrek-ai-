
import React from 'react';
import type { VoiceOption } from '../types';

interface VoiceSelectorProps {
  voices: VoiceOption[];
  selectedVoice: string;
  onVoiceChange: (voiceName: string) => void;
  disabled?: boolean;
}

export const VoiceSelector: React.FC<VoiceSelectorProps> = ({ voices, selectedVoice, onVoiceChange, disabled = false }) => {
  return (
    <div className="space-y-3">
      {voices.map((voice) => (
        <button
          key={voice.name}
          onClick={() => voice.available && onVoiceChange(voice.name)}
          disabled={!voice.available || disabled}
          className={`w-full text-right p-3 rounded-lg transition-all duration-200 border-2 ${
            selectedVoice === voice.name
              ? 'bg-yellow-400/20 border-yellow-400 text-white'
              : 'bg-gray-700/50 border-gray-600 hover:bg-gray-700 hover:border-gray-500'
          } ${!voice.available ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'} ${disabled ? 'cursor-not-allowed opacity-70' : ''}`}
        >
          <div className="flex items-center justify-between">
            <span className="font-bold">{voice.name}</span>
          </div>
          <div className="text-xs text-gray-300" style={{ fontFamily: 'Lora, serif' }}>{voice.description}</div>
          
          <div className="text-xs mt-1">
            {voice.apiName === 'טוען...' ? (
              <span className="text-gray-400 animate-pulse">{voice.apiName}</span>
            ) : voice.available ? (
              <span className="text-yellow-300/70">קול ממשי: {voice.apiName}</span>
            ) : (
              <span className="text-red-400">לא זמין</span>
            )}
          </div>
        </button>
      ))}
    </div>
  );
};
