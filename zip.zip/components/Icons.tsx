import React from 'react';

type IconProps = {
  className?: string;
};

export const SoulIcon: React.FC<IconProps> = ({ className }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="currentColor"
    className={className}
    aria-hidden="true"
  >
    <path
      fillRule="evenodd"
      d="M12 2.25c-2.484 0-4.75.966-6.436 2.652a8.966 8.966 0 00-2.652 6.436c0 4.95 4.014 8.964 8.964 8.964 2.484 0 4.75-.966 6.436-2.652a8.966 8.966 0 002.652-6.436C21.964 6.264 17.95 2.25 13.001 2.25A8.964 8.964 0 0012 2.25zm1.536 9.866a.75.75 0 01-1.072 0L9.93 9.578a.75.75 0 111.072-1.072l1.464 1.464 1.464-1.464a.75.75 0 111.072 1.072l-2.536 2.538zM12 6a.75.75 0 01.75.75v3a.75.75 0 01-1.5 0v-3A.75.75 0 0112 6z"
      clipRule="evenodd"
    />
    <path d="M4.5 12.75a7.5 7.5 0 0015 0h-15z" />
  </svg>
);

export const UserIcon: React.FC<IconProps> = ({ className }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    viewBox="0 0 24 24" 
    fill="currentColor" 
    className={className} 
    aria-hidden="true"
  >
    <path 
      fillRule="evenodd" 
      d="M7.5 6a4.5 4.5 0 119 0 4.5 4.5 0 01-9 0zM3.751 20.105a8.25 8.25 0 0116.498 0 .75.75 0 01-.437.695A18.683 18.683 0 0112 22.5c-2.786 0-5.433-.608-7.812-1.7a.75.75 0 01-.437-.695z" 
      clipRule="evenodd" 
    />
  </svg>
);


export const SendIcon: React.FC<IconProps> = ({ className }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    viewBox="0 0 24 24" 
    fill="currentColor" 
    className={className} 
    aria-hidden="true"
  >
    <path d="M3.478 2.405a.75.75 0 00-.926.94l2.432 7.905H13.5a.75.75 0 010 1.5H4.984l-2.432 7.905a.75.75 0 00.926.94 60.519 60.519 0 0018.445-8.986.75.75 0 000-1.218A60.517 60.517 0 003.478 2.405z" />
  </svg>
);

export const StopIcon: React.FC<IconProps> = ({ className }) => (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      viewBox="0 0 24 24" 
      fill="currentColor" 
      className={className}
      aria-hidden="true"
    >
      <path 
        fillRule="evenodd" 
        d="M4.5 7.5a3 3 0 013-3h9a3 3 0 013 3v9a3 3 0 01-3 3h-9a3 3 0 01-3-3v-9z" 
        clipRule="evenodd" 
      />
    </svg>
  );

export const CopyIcon: React.FC<IconProps> = ({ className }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="currentColor"
    className={className}
    aria-hidden="true"
  >
    <path
      fillRule="evenodd"
      d="M16.5 3H7.5a3 3 0 00-3 3v9a3 3 0 003 3h9a3 3 0 003-3V6a3 3 0 00-3-3zm-9 1.5A1.5 1.5 0 019 3h6a1.5 1.5 0 011.5 1.5v9A1.5 1.5 0 0115 15H9a1.5 1.5 0 01-1.5-1.5v-9zm-1.5 3A.75.75 0 004.5 9v6A1.5 1.5 0 006 16.5h6a.75.75 0 000-1.5H6A.75.75 0 015.25 15V9a.75.75 0 00-.75-.75z"
      clipRule="evenodd"
    />
  </svg>
);

export const CheckIcon: React.FC<IconProps> = ({ className }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="currentColor"
    className={className}
    aria-hidden="true"
  >
    <path 
      fillRule="evenodd" 
      d="M19.916 4.626a.75.75 0 01.208 1.04l-9 13.5a.75.75 0 01-1.154.114l-6-6a.75.75 0 011.06-1.06l5.353 5.353 8.493-12.739a.75.75 0 011.04-.208z" 
      clipRule="evenodd" 
    />
  </svg>
);


export const MicrophoneIcon: React.FC<IconProps> = ({ className }) => (
    <svg 
        xmlns="http://www.w3.org/2000/svg" 
        viewBox="0 0 24 24" 
        fill="currentColor" 
        className={className}
        aria-hidden="true"
    >
        <path d="M8.25 4.5a3.75 3.75 0 117.5 0v8.25a3.75 3.75 0 11-7.5 0V4.5z" />
        <path d="M6 10.5a.75.75 0 01.75.75v1.5a5.25 5.25 0 1010.5 0v-1.5a.75.75 0 011.5 0v1.5a6.75 6.75 0 11-13.5 0v-1.5A.75.75 0 016 10.5z" />
    </svg>
);